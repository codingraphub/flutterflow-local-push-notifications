package com.mycompany.pushnotifications

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
